package com.linyang.customviewdemo.ui;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.linyang.customviewdemo.R;

/**
 * 描述:多边形网格属性图
 * Created by fzJiang on 2018-08-22
 */
public class PolygonViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_polygon_view);
    }

}
