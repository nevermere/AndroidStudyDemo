package com.linyang.customviewdemo.ui;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.linyang.customviewdemo.R;
import com.linyang.customviewdemo.widget.MyNavView;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * 描述:实现字母导航栏
 * Created by fzJiang on 2018-08-22
 */
public class NavViewActivity extends AppCompatActivity {

    @BindView(R.id.search_view)
    EditText mSearchView;
    @BindView(R.id.list_view)
    ListView mListView;
    @BindView(R.id.tint_view)
    TextView mTintView;
    @BindView(R.id.nav_view)
    MyNavView mNavView;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_nav_view);
        ButterKnife.bind(this);

        mNavView.setTextView(mTintView);
    }
}
