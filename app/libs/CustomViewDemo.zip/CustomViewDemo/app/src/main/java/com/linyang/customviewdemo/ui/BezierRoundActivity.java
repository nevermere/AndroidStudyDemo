package com.linyang.customviewdemo.ui;

import android.os.Bundle;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.linyang.customviewdemo.R;

/**
 * 描述:
 * Created by fzJiang on 2018-11-02
 */
public class BezierRoundActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_bezier_round_view);
    }
}
