package com.linyang.customviewdemo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.linyang.customviewdemo.ui.BezierRoundActivity;
import com.linyang.customviewdemo.ui.CardViewActivity;
import com.linyang.customviewdemo.ui.ChatViewActivity;
import com.linyang.customviewdemo.ui.CycleViewActivity;
import com.linyang.customviewdemo.ui.GuaGuaKaViewActivity;
import com.linyang.customviewdemo.ui.LeafLoadingActivity;
import com.linyang.customviewdemo.ui.MyScrollViewActivity;
import com.linyang.customviewdemo.ui.NavViewActivity;
import com.linyang.customviewdemo.ui.PolygonViewActivity;
import com.linyang.customviewdemo.ui.StatisticsViewActivity;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

/**
 * 描述:自定义view
 * Created by fzJiang on 2018-08-22
 */
public class MainActivity extends AppCompatActivity {

    @BindView(R.id.bt_card_view)
    AppCompatButton btCardView;
    @BindView(R.id.bt_polygon_view)
    AppCompatButton btPolygonView;
    @BindView(R.id.bt_line_view)
    AppCompatButton btLineView;
    @BindView(R.id.bt_chat_view)
    AppCompatButton btChatView;
    @BindView(R.id.bt_guaguaka_view)
    AppCompatButton btGuaguakaView;
    @BindView(R.id.bt_cycle_view)
    AppCompatButton mBtCycleView;
    @BindView(R.id.bt_nav_view)
    AppCompatButton mBtNavView;
    @BindView(R.id.bt_leaf_load_view)
    AppCompatButton mBtLeafLoadView;
    @BindView(R.id.bt_bezier_round)
    AppCompatButton mBtBezierRound;
    @BindView(R.id.bt_scroll_view)
    AppCompatButton mBtScrollView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
    }

    @OnClick({
            R.id.bt_card_view,
            R.id.bt_polygon_view,
            R.id.bt_line_view,
            R.id.bt_chat_view,
            R.id.bt_guaguaka_view,
            R.id.bt_cycle_view,
            R.id.bt_nav_view,
            R.id.bt_leaf_load_view,
            R.id.bt_bezier_round,
            R.id.bt_scroll_view
    })
    public void onViewClicked(View view) {
        switch (view.getId()) {
            case R.id.bt_card_view:
                startActivity(new Intent(this, CardViewActivity.class));
                break;

            case R.id.bt_polygon_view:
                startActivity(new Intent(this, PolygonViewActivity.class));
                break;

            case R.id.bt_line_view:
                startActivity(new Intent(this, StatisticsViewActivity.class));
                break;

            case R.id.bt_chat_view:
                startActivity(new Intent(this, ChatViewActivity.class));
                break;

            case R.id.bt_guaguaka_view:
                startActivity(new Intent(this, GuaGuaKaViewActivity.class));
                break;

            case R.id.bt_cycle_view:
                startActivity(new Intent(this, CycleViewActivity.class));
                break;

            case R.id.bt_nav_view:
                startActivity(new Intent(this, NavViewActivity.class));
                break;

            case R.id.bt_leaf_load_view:
                startActivity(new Intent(this, LeafLoadingActivity.class));
                break;

            case R.id.bt_bezier_round:
                startActivity(new Intent(this, BezierRoundActivity.class));
                break;

            case R.id.bt_scroll_view:
                startActivity(new Intent(this, MyScrollViewActivity.class));
                break;
        }
    }
}
