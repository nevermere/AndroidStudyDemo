package com.linyang.customviewdemo.ui;

import android.os.Bundle;

import com.linyang.customviewdemo.R;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

/**
 * 描述:
 * Created by fzJiang on 2018-11-09
 */
public class MyScrollViewActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_my_scroll_view);
    }
}
